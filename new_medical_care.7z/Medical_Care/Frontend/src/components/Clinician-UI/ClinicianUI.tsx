import React, { useState, useEffect, useRef } from "react";
import { ChatBackend, Message } from "../../types/chat";
import { MessageBubble } from "../Chat-UI/MessageBubble";
import { ArrowUpCircle, Users, Stethoscope, ClipboardList, Settings, Mic, UploadCloud, Activity, LogOut } from "lucide-react";
import { handleUserInput } from "../../adapters/chatservice";
import { useAuth } from "../../contexts/AuthContext";
import { useNavigate } from "react-router-dom";

/* -------------------------- Clinician Types --------------------------- */

interface PatientListItem {
  id: string;
  name: string;
  age: number;
  gender: string;
  mrn: string;
}

interface PatientDetails {
  id: string;
  name: string;
  age: number;
  gender: string;
  mrn: string;
  lastVisit: string;

  // vitals
  hr: number;
  bp: string;
  temp: number;
  spo2: number;

  // medical history
  diagnoses: string[];
  medications: string[];
  activeConditions: string[];

  // follow-up plan
  plan: string | null;
  nextSteps: string | null;

  // AI triage result (filled by AI)
  aiTriage: string | null;
}

/* ------------------------ Clinician UI Component ------------------------ */

export default function ClinicianUI({ backend }: { backend: ChatBackend }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  /* Redirect if not logged in */
  useEffect(() => {
    if (!user) navigate("/");
  }, [user, navigate]);

  /* ------------------------------- State ------------------------------ */

  const [patients, setPatients] = useState<PatientListItem[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<PatientDetails | null>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const [error, setError] = useState<string | null>(null);

  /* -------------------------- Load Patients List -------------------------- */
  useEffect(() => {
    async function loadPatients() {
      try {
        const res = await fetch("http://localhost:8000/patient-list");
        const data = await res.json();
        setPatients(data);
      } catch (err) {
        console.error("Failed to load patients", err);
        setPatients([]);
      }
    }

    loadPatients();
  }, []);

  /* --------------------------- Load Patient Details ------------------------- */
  async function loadPatientDetails(id: string) {
    try {
      const res = await fetch(`http://localhost:8000/patient/${id}`);
      const data = await res.json();
      setSelectedPatient(data);
      setMessages([]); // reset chat for each patient
    } catch (err) {
      console.error("Failed to load patient details", err);
    }
  }

  /* ----------------------------- Chat Send Message ----------------------------- */

  const sendMessage = async () => {
    if (!input.trim() || sending) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setSending(true);
    setError(null);
    setStreamingText("");

    try {
      const payload = [
        ...messages.map((m) => `${m.role === "user" ? "Clinician" : "Assistant"}: ${m.content}`),
        `Clinician: ${userMsg.content}`,
        selectedPatient
          ? `\nContext: Patient demographics: ${selectedPatient.name}, ${selectedPatient.age} years, ${selectedPatient.gender}. Recent vitals: HR=${selectedPatient.hr}, BP=${selectedPatient.bp}, Temp=${selectedPatient.temp}, SpO2=${selectedPatient.spo2}. Diagnoses: ${selectedPatient.diagnoses.join(", ") || "None"}`
          : ""
      ].join("\n");

      if (typeof (backend as any).streamMessage === "function") {
        setIsStreaming(true);

        await (backend as any).streamMessage(
          payload,
          (chunk: string) => {
            setStreamingText((prev) => prev + chunk);
          },
          (finalMsg: Message | null) => {
            if (finalMsg) {
              setMessages((prev) => [...prev, finalMsg]);

              /* Capture AI triage output if present */
              if (finalMsg.content.includes("Triage:")) {
                setSelectedPatient((prev) =>
                  prev ? { ...prev, aiTriage: finalMsg.content } : prev
                );
              }
            }
            setIsStreaming(false);
          }
        );
      } else {
        const reply = await handleUserInput(backend, payload, []);
        const botMsg: Message = { ...reply };
        setMessages((prev) => [...prev, botMsg]);
      }
    } catch (err: any) {
      console.error(err);
      setError("Error sending message.");
    } finally {
      setSending(false);
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  /* ------------------------------- Auto-scroll ------------------------------- */
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingText]);

  /* ------------------------------- Render UI ------------------------------- */

  return (
    <div className="h-screen flex bg-[#021827] text-white overflow-hidden">

      {/* ------------------ LEFT SIDEBAR ------------------ */}
      <div className="w-60 bg-[#00131f] border-r border-slate-800 flex flex-col p-4">
        <div className="text-xl font-bold mb-6 flex items-center gap-2">
          <Stethoscope className="w-6 h-6 text-sky-400" /> Clinician Portal
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-3 text-sm">
          <button className="flex items-center gap-2 p-2 rounded hover:bg-sky-900/40">
            <Activity size={16} /> Dashboard
          </button>

          <div className="text-xs uppercase text-slate-400 mt-4 mb-1">Patients</div>

          <div className="space-y-1 max-h-64 overflow-auto pr-1">
            {patients.map((p) => (
              <button
                key={p.id}
                onClick={() => loadPatientDetails(p.id)}
                className={`w-full text-left px-2 py-1 rounded ${
                  selectedPatient?.id === p.id
                    ? "bg-sky-600 text-white"
                    : "hover:bg-slate-700/60"
                }`}
              >
                {p.name} — {p.mrn}
              </button>
            ))}
          </div>

          <hr className="my-4 border-slate-700" />

          <button className="flex items-center gap-2 p-2 rounded hover:bg-sky-900/40">
            <ClipboardList size={16} /> Reports
          </button>

          <button className="flex items-center gap-2 p-2 rounded hover:bg-sky-900/40">
            <Settings size={16} /> Settings
          </button>

          <button
            onClick={() => logout()}
            className="flex items-center gap-2 p-2 mt-auto text-red-400 hover:bg-red-900/30 rounded"
          >
            <LogOut size={16} /> Logout
          </button>
        </nav>
      </div>

      {/* ------------------ MAIN CHAT PANEL ------------------ */}
      <div className="flex-1 p-6 flex flex-col">
        <div className="text-2xl font-semibold mb-3">AI Triage Assistant</div>

        <div className="flex-1 bg-white text-black rounded-xl p-4 overflow-auto shadow">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}

          {isStreaming && (
            <div className="bg-gray-100 p-2 rounded whitespace-pre-wrap border-l-4 border-sky-400">
              {streamingText}
              <span className="animate-pulse">|</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="mt-4">
          <div className="bg-white rounded-lg border shadow px-3 py-2 flex items-center gap-3">
            <textarea
              ref={inputRef}
              rows={1}
              className="flex-1 px-2 py-2 focus:outline-none resize-none bg-transparent"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), sendMessage())}
              placeholder="Ask clinical questions, generate triage, check history…"
            />

            <button
              className="w-10 h-10 rounded-full bg-sky-600 text-white flex items-center justify-center"
              onClick={sendMessage}
            >
              <ArrowUpCircle size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* ------------------ RIGHT: PATIENT EHR PANEL ------------------ */}
      <div className="w-[360px] bg-white text-slate-900 p-6 overflow-auto border-l border-slate-200">
        {!selectedPatient ? (
          <div className="text-center text-slate-500 mt-20">Select a patient to view details</div>
        ) : (
          <div className="space-y-6">

            {/* Header */}
            <div>
              <div className="text-xl font-semibold">{selectedPatient.name}</div>
              <div className="text-sm text-slate-500">
                {selectedPatient.age} yrs • {selectedPatient.gender} • MRN: {selectedPatient.mrn}
              </div>
              <div className="text-xs text-slate-500">Last visit: {selectedPatient.lastVisit}</div>
            </div>

            {/* Vitals */}
            <section className="border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-1">Vitals</h3>
              <div className="grid grid-cols-2 gap-y-1 text-xs">
                <div>HR: {selectedPatient.hr} bpm</div>
                <div>BP: {selectedPatient.bp}</div>
                <div>Temp: {selectedPatient.temp}°C</div>
                <div>SpO₂: {selectedPatient.spo2}%</div>
              </div>
            </section>

            {/* Diagnoses */}
            <section className="border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-1">Past Diagnoses</h3>
              <ul className="list-disc pl-4 text-xs leading-tight">
                {selectedPatient.diagnoses.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </section>

            {/* Active Conditions */}
            <section className="border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-1">Active Conditions</h3>
              <ul className="list-disc pl-4 text-xs">
                {selectedPatient.activeConditions.map((c, i) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
            </section>

            {/* Medications */}
            <section className="border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-1">Medications</h3>
              <ul className="list-disc pl-4 text-xs">
                {selectedPatient.medications.map((m, i) => (
                  <li key={i}>{m}</li>
                ))}
              </ul>
            </section>

            {/* AI Triage */}
            {selectedPatient.aiTriage && (
              <section className="border border-sky-300 rounded-xl p-4 bg-sky-50">
                <h3 className="font-semibold text-sm text-sky-800 mb-1">AI Triage Result</h3>
                <p className="text-xs whitespace-pre-wrap">{selectedPatient.aiTriage}</p>
              </section>
            )}

            {/* Follow-up */}
            <section className="border border-slate-200 rounded-xl p-4">
              <h3 className="font-semibold text-sm mb-1">Follow-Up Plan</h3>
              <p className="text-xs">{selectedPatient.plan || "—"}</p>
              <h3 className="font-semibold text-sm mt-2 mb-1">Next Steps</h3>
              <p className="text-xs">{selectedPatient.nextSteps || "—"}</p>
            </section>

          </div>
        )}
      </div>
    </div>
  );
}
